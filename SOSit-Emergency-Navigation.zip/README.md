# SOSit – Emergency Navigation

SOSit is a simple web app using the **TomTom Maps API** to help users navigate in emergency situations to the **nearest hospital, petrol pump, or fire station**.

## 🌍 Features
- Live location tracking like Google Maps
- Dynamic route drawing (blue line)
- Responsive layout
- TomTom fuzzy search and routing

## 🚀 How to Use

1. Replace `YOUR_TOMTOM_API_KEY` in `index.html` with your TomTom API key
2. Open the file in a browser (`index.html`)
3. Allow location access
4. Click on a button to navigate to the nearest:
   - 🏥 Hospital
   - ⛽ Petrol Pump
   - 🚒 Fire Station

## 📦 Deploy
You can deploy it using:
- GitHub Pages
- Netlify
- Vercel

## 🔐 API Key
Get your API key from [TomTom Developer Portal](https://developer.tomtom.com/)

---

Made with ❤️ for emergencies.
